package com.example.phone.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;

/**
 * The phone item only reacts to right-click. All GUI and call logic lives elsewhere
 * (client entrypoint opens the GUI, server-side managers handle calls), so this class
 * stays free of client-only references and is safe on a dedicated server.
 */
public class PhoneItem extends Item {
    public PhoneItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        // The GUI is opened by the client-side callback registered in PhoneModClient.
        return InteractionResult.SUCCESS;
    }
}