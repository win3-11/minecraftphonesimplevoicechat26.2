package com.example.phone.item;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Server-side check for "does this player actually own a phone?".
 *
 * <p>Kept separate from {@link PhoneItem} because this is a rule used by call validation,
 * not item behaviour. Everything here runs on the server, so a client cannot fake it.
 */
public final class PhoneOwnership {

    private PhoneOwnership() {
    }

    /**
     * Checks the whole player inventory (hotbar + main + offhand), not only the selected
     * slot, so a player who put the phone in their chest still keeps their number.
     */
    public static boolean hasPhone(Player player) {
        if (player == null) {
            return false;
        }
        return player.getInventory().contains(PhoneOwnership::isPhone);
    }

    public static boolean isPhone(ItemStack stack) {
        return stack != null && stack.is(PhoneItems.PHONE);
    }
}
