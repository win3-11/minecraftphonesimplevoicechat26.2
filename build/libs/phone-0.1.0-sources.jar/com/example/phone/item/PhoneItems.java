package com.example.phone.item;

import com.example.phone.PhoneMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

public final class PhoneItems {
    public static final Identifier PHONE_ID = Identifier.fromNamespaceAndPath(PhoneMod.MOD_ID, "phone");

    /**
     * Since 26.2 Item.Properties#setId is mandatory: the item id must be known before the
     * Item constructor runs (Item#effectiveDescriptionId throws "Item id not set" otherwise).
     */
    public static final ResourceKey<Item> PHONE_KEY =
            ResourceKey.create(Registries.ITEM, PHONE_ID);

    public static final Item PHONE = Registry.register(
            BuiltInRegistries.ITEM,
            PHONE_KEY,
            new PhoneItem(new Item.Properties().setId(PHONE_KEY).stacksTo(1)));

    private PhoneItems() {
    }

    /** Touches the class so the static registration above runs. */
    public static void register() {
    }
}