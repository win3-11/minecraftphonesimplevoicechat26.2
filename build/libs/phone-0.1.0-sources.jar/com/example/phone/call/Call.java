package com.example.phone.call;

import java.util.UUID;

/**
 * A single phone call. Independent of any GUI: it exists on the server only and lives
 * from the moment the caller places the call until it is removed after ENDED.
 */
public final class Call {

    private final UUID caller;
    private final UUID target;
    private UUID voiceGroupId;
    private CallState state;

    public Call(UUID caller, UUID target, UUID voiceGroupId) {
        this.caller = caller;
        this.target = target;
        this.voiceGroupId = voiceGroupId;
        this.state = CallState.RINGING;
    }

    public UUID caller() {
        return caller;
    }

    public UUID target() {
        return target;
    }

    /** Simple Voice Chat group id reserved for this call, or null if not created yet. */
    public UUID voiceGroupId() {
        return voiceGroupId;
    }

    public void setVoiceGroupId(UUID voiceGroupId) {
        this.voiceGroupId = voiceGroupId;
    }

    public CallState state() {
        return state;
    }

    public boolean isRinging() {
        return state == CallState.RINGING;
    }

    public boolean isConnected() {
        return state == CallState.CONNECTED;
    }

    public boolean isEnded() {
        return state == CallState.ENDED;
    }

    /**
     * Server-side state transition. Never called from client-received data directly.
     */
    public void setState(CallState newState) {
        this.state = newState;
    }

    /** @return true if the given player is one of the two participants. */
    public boolean involves(UUID playerId) {
        return caller.equals(playerId) || target.equals(playerId);
    }

    /** @return the other participant, or null if the player is not part of this call. */
    public UUID otherParty(UUID playerId) {
        if (caller.equals(playerId)) {
            return target;
        }
        if (target.equals(playerId)) {
            return caller;
        }
        return null;
    }
}