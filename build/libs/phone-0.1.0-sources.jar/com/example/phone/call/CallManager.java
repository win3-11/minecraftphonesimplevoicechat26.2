package com.example.phone.call;

import com.example.phone.PhoneMod;
import com.example.phone.item.PhoneOwnership;
import com.example.phone.phone.PhoneSounds;
import com.example.phone.voice.VoiceChatManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Central server-side authority for phone calls.
 *
 * Every decision about a call is made here and only here. Clients may only ask for an
 * action (start / accept / reject / hang up) — they can never set a CallState directly
 * and they never touch Simple Voice Chat.
 */
public final class CallManager {

    /**
     * Notified whenever a call changes so the networking layer can push it to clients.
     * Keeps CallManager free of any packet / networking code.
     */
    public interface CallNotifier {
        void onIncomingCall(Call call, ServerPlayer target, ServerPlayer caller);

        void onCallStarted(Call call, ServerPlayer player, ServerPlayer peer);

        void onCallEnded(Call call, ServerPlayer player, String reason);
    }

    private static final CallManager INSTANCE = new CallManager();

    /** player UUID -> the call this player currently participates in. */
    private final Map<UUID, Call> activeCalls = new HashMap<>();

    private volatile CallNotifier notifier = NOOP;

    private static final CallNotifier NOOP = new CallNotifier() {
        @Override
        public void onIncomingCall(Call call, ServerPlayer target, ServerPlayer caller) {
        }

        @Override
        public void onCallStarted(Call call, ServerPlayer player, ServerPlayer peer) {
        }

        @Override
        public void onCallEnded(Call call, ServerPlayer player, String reason) {
        }
    };

    private CallManager() {
    }

    public static CallManager getInstance() {
        return INSTANCE;
    }

    public void setNotifier(CallNotifier notifier) {
        this.notifier = notifier == null ? NOOP : notifier;
    }

    /** Clears all calls. Called once when the server stops. */
    public void reset() {
        for (Call call : new ArrayList<>(activeCalls.values())) {
            endCall(call, "server_stop");
        }
        activeCalls.clear();
        VoiceChatManager.reset();
    }

    public Call getCall(UUID playerId) {
        return activeCalls.get(playerId);
    }

    public boolean isBusy(UUID playerId) {
        return activeCalls.containsKey(playerId);
    }

    /**
     * All server-side checks required before a call may be created.
     * Never trust the client: the caller and the target are resolved from the UUID the
     * client sent, and both must be real, online players on this server.
     */
    public boolean canCall(ServerPlayer caller, ServerPlayer target) {
        if (caller == null || target == null) {
            return false;
        }
        if (caller.getUUID().equals(target.getUUID())) {
            return false;
        }
        if (!isOnline(target)) {
            return false;
        }
        // No phone, no call — in either direction.
        if (!PhoneOwnership.hasPhone(caller) || !PhoneOwnership.hasPhone(target)) {
            return false;
        }
        if (isBusy(caller.getUUID())) {
            return false;
        }
        if (isBusy(target.getUUID())) {
            return false;
        }
        return isCallable(target);
    }

    /**
     * Starts a call. All validation happens server side; an invalid request is rejected
     * silently (the client cannot be trusted and must not be told details).
     *
     * @return the created call, or null if the request was invalid
     */
    public Call startCall(ServerPlayer caller, ServerPlayer target) {
        if (!canCall(caller, target)) {
            PhoneMod.LOGGER.debug("[phone] rejected call {} -> {}", safeName(caller), safeName(target));
            return null;
        }

        Call call = new Call(caller.getUUID(), target.getUUID(), null);
        activeCalls.put(caller.getUUID(), call);
        activeCalls.put(target.getUUID(), call);
        PhoneMod.LOGGER.info("[phone] call started: {} -> {}", safeName(caller), safeName(target));

        notifier.onIncomingCall(call, target, caller);
        PhoneSounds.playRinging(target);
        return call;
    }

    /**
     * The callee accepts. Only valid while the call is still RINGING, so accepting an
     * already cancelled or already connected call is rejected.
     *
     * @return the accepted call, or null if it was not valid
     */
    public Call acceptCall(ServerPlayer target) {
        Call call = getCall(target.getUUID());
        if (call == null || !call.target().equals(target.getUUID()) || !call.isRinging()) {
            return null;
        }
        // The callee may have dropped the phone while it was ringing.
        if (!PhoneOwnership.hasPhone(target)) {
            endCall(call, "no_phone");
            return null;
        }

        call.setState(CallState.CONNECTED);
        PhoneMod.LOGGER.info("[phone] call accepted, now CONNECTED");

        ServerPlayer caller = find(call.caller());
        ServerPlayer callee = find(call.target());

        // Put both players into one private Simple Voice Chat group, so they can talk
        // regardless of the distance between them in the world.
        if (caller != null && callee != null) {
            UUID groupId = VoiceChatManager.connectPlayers(caller, callee);
            if (groupId != null) {
                call.setVoiceGroupId(groupId);
            } else {
                PhoneMod.LOGGER.warn("[phone] voice connection failed, call stays UI-only");
            }
        }

        if (caller != null) {
            notifier.onCallStarted(call, caller, callee);
        }
        if (callee != null) {
            notifier.onCallStarted(call, callee, caller);
        }
        PhoneSounds.playAccepted(caller);
        PhoneSounds.playAccepted(callee);
        return call;
    }

    /**
     * The callee rejects. Rejecting an already finished call is a no-op.
     */
    public boolean rejectCall(ServerPlayer target) {
        Call call = getCall(target.getUUID());
        if (call == null || !call.target().equals(target.getUUID()) || !call.isRinging()) {
            return false;
        }
        endCall(call, "rejected");
        return true;
    }

    /**
     * Either party hangs up. Calling it several times is safe: the second call finds no
     * active call and does nothing.
     */
    public boolean hangUp(ServerPlayer player) {
        return endCall(getCall(player.getUUID()), "hang_up");
    }

    /**
     * A player left the server: cancel a RINGING call, tear down a CONNECTED one.
     * Automatic, and it always removes the call from the active set.
     */
    public void handleDisconnect(ServerPlayer player) {
        Call call = getCall(player.getUUID());
        VoiceChatManager.handleDisconnect(player);
        if (call == null) {
            return;
        }
        CallState state = call.state();
        endCall(call, "disconnect");
        PhoneMod.LOGGER.info("[phone] player disconnected during {}", state);
    }

    /**
     * Players the given viewer may currently call: online, not the viewer, not busy,
     * and callable. Used to build the phone GUI list.
     */
    public List<ServerPlayer> getCallablePlayers(ServerPlayer viewer) {
        List<ServerPlayer> result = new ArrayList<>();
        // Without a phone there is nothing to call from, so the list is empty.
        if (!PhoneOwnership.hasPhone(viewer)) {
            return result;
        }
        for (ServerPlayer other : viewer.level().getServer().getPlayerList().getPlayers()) {
            if (other.getUUID().equals(viewer.getUUID())) {
                continue;
            }
            if (isBusy(other.getUUID()) || !isCallable(other)) {
                continue;
            }
            // Someone without a phone cannot be reached.
            if (!PhoneOwnership.hasPhone(other)) {
                continue;
            }
            result.add(other);
        }
        return result;
    }

    /** Whether this player currently accepts incoming calls at all. */
    public boolean isCallable(ServerPlayer player) {
        // No opt-out system in the MVP: every online player is callable.
        return player.isAlive() && !player.isSpectator();
    }

    // --- internals -----------------------------------------------------------

    private boolean endCall(Call call, String reason) {
        if (call == null) {
            return false;
        }
        call.setState(CallState.ENDED);
        activeCalls.remove(call.caller());
        activeCalls.remove(call.target());

        // Tear the voice connection down before telling anybody, so a player who
        // immediately starts a new call is not put back into the old group.
        ServerPlayer caller = find(call.caller());
        ServerPlayer callee = find(call.target());
        VoiceChatManager.disconnectPlayers(call.voiceGroupId(), caller, callee);
        call.setVoiceGroupId(null);

        // Both parties are told, so nobody is left with a stuck screen.
        if (caller != null) {
            notifier.onCallEnded(call, caller, reason);
        }
        if (callee != null) {
            notifier.onCallEnded(call, callee, reason);
        }
        PhoneSounds.playEnded(caller);
        PhoneSounds.playEnded(callee);
        return true;
    }

    /** Server-side player lookup; null when the player is offline. */
    private static ServerPlayer find(UUID playerId) {
        MinecraftServer server = SERVER.get();
        if (server == null) {
            return null;
        }
        return server.getPlayerList().getPlayer(playerId);
    }

    /** Holds the running server so the notifier can resolve players by UUID. */
    private static final java.util.concurrent.atomic.AtomicReference<MinecraftServer> SERVER =
            new java.util.concurrent.atomic.AtomicReference<>();

    public static void setServer(MinecraftServer server) {
        SERVER.set(server);
    }

    private boolean isOnline(ServerPlayer player) {
        return player.level().getServer().getPlayerList().getPlayer(player.getUUID()) != null;
    }

    private static String safeName(ServerPlayer player) {
        return player == null ? "<offline>" : String.valueOf(player.getGameProfile().name());
    }
}