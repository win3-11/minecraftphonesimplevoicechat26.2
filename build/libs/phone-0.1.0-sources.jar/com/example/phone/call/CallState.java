package com.example.phone.call;

/**
 * Lifecycle of a phone call. Only the server may change this.
 */
public enum CallState {
    /** The call was placed, the callee has not accepted yet. */
    RINGING,
    /** The callee accepted, the voice connection is (being) established. */
    CONNECTED,
    /** The call is over; the Call object is removed from CallManager. */
    ENDED
}