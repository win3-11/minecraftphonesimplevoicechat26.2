package com.example.phone;

import com.example.phone.call.CallManager;
import com.example.phone.item.PhoneItems;
import com.example.phone.network.PhoneNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PhoneMod implements ModInitializer {
    public static final String MOD_ID = "phone";
    public static final Logger LOGGER = LoggerFactory.getLogger("phone-mod");

    @Override
    public void onInitialize() {
        PhoneItems.register();
        PhoneNetworking.registerServerbound();

        // A player leaving the server must automatically cancel or tear down their call.
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                CallManager.getInstance().handleDisconnect(handler.player));

        // Remember the running server so the notifier can resolve players by UUID.
        ServerLifecycleEvents.SERVER_STARTED.register(CallManager::setServer);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            CallManager.getInstance().reset();
            CallManager.setServer(null);
        });

        LOGGER.info("[phone] mod initialised");
    }
}