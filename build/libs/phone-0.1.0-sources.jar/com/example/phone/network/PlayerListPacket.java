package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * SERVER -> CLIENT payload with the list of players currently online that can be called.
 * This is the only source of truth for the GUI list.
 */
public record PlayerListPacket(List<Contact> contacts) implements CustomPacketPayload {

    public record Contact(UUID uuid, String name) {
    }

    public static final CustomPacketPayload.Type<PlayerListPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.PLAYER_LIST);

    public static final StreamCodec<RegistryFriendlyByteBuf, PlayerListPacket> CODEC =
            StreamCodec.of((buf, value) -> {
                buf.writeVarInt(value.contacts().size());
                for (Contact contact : value.contacts()) {
                    buf.writeUUID(contact.uuid());
                    buf.writeUtf(contact.name());
                }
            }, buf -> {
                int size = buf.readVarInt();
                List<Contact> list = new ArrayList<>(size);
                for (int i = 0; i < size; i++) {
                    list.add(new Contact(buf.readUUID(), buf.readUtf()));
                }
                return new PlayerListPacket(list);
            });

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}