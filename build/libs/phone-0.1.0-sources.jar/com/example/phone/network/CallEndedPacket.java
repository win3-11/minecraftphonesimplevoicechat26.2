package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.UUID;

/**
 * SERVER -> CLIENT: the call is over. Sent to both parties whenever a call ends,
 * no matter the reason (hang up, reject, disconnect, server stop).
 */
public record CallEndedPacket(UUID peerId, String reason) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<CallEndedPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.CALL_ENDED);

    public static final StreamCodec<RegistryFriendlyByteBuf, CallEndedPacket> CODEC =
            StreamCodec.of((buf, value) -> {
                buf.writeUUID(value.peerId());
                buf.writeUtf(value.reason());
            }, buf -> new CallEndedPacket(buf.readUUID(), buf.readUtf()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}