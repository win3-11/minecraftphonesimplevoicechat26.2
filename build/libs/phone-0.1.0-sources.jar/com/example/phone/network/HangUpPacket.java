package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * CLIENT -> SERVER: "end my current call". Safe to spam: the second call is a no-op.
 */
public record HangUpPacket() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<HangUpPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.HANG_UP);

    public static final StreamCodec<RegistryFriendlyByteBuf, HangUpPacket> CODEC =
            StreamCodec.of((buf, value) -> {
            }, buf -> new HangUpPacket());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}