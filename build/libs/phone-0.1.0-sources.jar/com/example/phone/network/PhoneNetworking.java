package com.example.phone.network;

import com.example.phone.PhoneMod;
import com.example.phone.call.Call;
import com.example.phone.call.CallManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Networking entry point.
 *
 * On a physical client BOTH payload types must be registered from the common
 * initializer: the client has to decode the serverbound packets too, and Fabric only
 * accepts one registration per packet id (a second call throws
 * "Packet type Type[id=...] is already registered!").
 *
 * Every handler resolves the acting player from the connection, never from packet data,
 * and delegates the decision to CallManager. Clients never set a call state themselves.
 */
public final class PhoneNetworking {

    private PhoneNetworking() {
    }

    public static void registerServerbound() {
        registerPayloadTypes();
        registerReceivers();
        registerNotifier();
    }

    private static void registerPayloadTypes() {
        PayloadTypeRegistry.serverboundPlay().register(PlayerListRequestPacket.TYPE, PlayerListRequestPacket.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(CallRequestPacket.TYPE, CallRequestPacket.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(AcceptCallPacket.TYPE, AcceptCallPacket.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(RejectCallPacket.TYPE, RejectCallPacket.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(HangUpPacket.TYPE, HangUpPacket.CODEC);

        PayloadTypeRegistry.clientboundPlay().register(PlayerListPacket.TYPE, PlayerListPacket.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(IncomingCallPacket.TYPE, IncomingCallPacket.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(CallStartedPacket.TYPE, CallStartedPacket.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(CallEndedPacket.TYPE, CallEndedPacket.CODEC);
    }

    private static void registerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(PlayerListRequestPacket.TYPE,
                (payload, context) -> context.server().execute(() -> {
                    ServerPlayer viewer = context.player();
                    if (viewer == null) {
                        return;
                    }
                    List<PlayerListPacket.Contact> contacts = collectCallablePlayers(viewer);
                    ServerPlayNetworking.send(viewer, new PlayerListPacket(contacts));
                }));

        ServerPlayNetworking.registerGlobalReceiver(CallRequestPacket.TYPE,
                (payload, context) -> context.server().execute(() -> {
                    ServerPlayer caller = context.player();
                    if (caller == null) {
                        return;
                    }
                    // The client only suggests a UUID; it is resolved and validated here.
                    ServerPlayer target = resolveOnline(caller, payload.targetId());
                    CallManager.getInstance().startCall(caller, target);
                }));

        ServerPlayNetworking.registerGlobalReceiver(AcceptCallPacket.TYPE,
                (payload, context) -> context.server().execute(() -> {
                    ServerPlayer player = context.player();
                    if (player != null) {
                        CallManager.getInstance().acceptCall(player);
                    }
                }));

        ServerPlayNetworking.registerGlobalReceiver(RejectCallPacket.TYPE,
                (payload, context) -> context.server().execute(() -> {
                    ServerPlayer player = context.player();
                    if (player != null) {
                        CallManager.getInstance().rejectCall(player);
                    }
                }));

        ServerPlayNetworking.registerGlobalReceiver(HangUpPacket.TYPE,
                (payload, context) -> context.server().execute(() -> {
                    ServerPlayer player = context.player();
                    if (player != null) {
                        CallManager.getInstance().hangUp(player);
                    }
                }));
    }

    /**
     * Pushes call state changes to clients. This is the only place that touches packets
     * for outgoing calls; CallManager itself knows nothing about networking.
     */
    private static void registerNotifier() {
        CallManager.getInstance().setNotifier(new CallManager.CallNotifier() {
            @Override
            public void onIncomingCall(Call call, ServerPlayer target, ServerPlayer caller) {
                ServerPlayNetworking.send(target, new IncomingCallPacket(call.caller(), nameOf(caller)));
            }

            @Override
            public void onCallStarted(Call call, ServerPlayer player, ServerPlayer peer) {
                if (player == null) {
                    return;
                }
                UUID peerId = peer == null ? call.otherParty(player.getUUID()) : peer.getUUID();
                ServerPlayNetworking.send(player, new CallStartedPacket(peerId, nameOf(peer)));
            }

            @Override
            public void onCallEnded(Call call, ServerPlayer player, String reason) {
                UUID peerId = call.otherParty(player.getUUID());
                ServerPlayNetworking.send(player, new CallEndedPacket(peerId, reason));
            }
        });
    }

    // --- helpers --------------------------------------------------------------

    /**
     * Resolves a UUID sent by a client to a real, online player on this server.
     * Returns null for unknown or offline UUIDs, which makes every check fail safely.
     */
    private static ServerPlayer resolveOnline(ServerPlayer caller, UUID targetId) {
        return caller.level().getServer().getPlayerList().getPlayer(targetId);
    }

    private static String nameOf(ServerPlayer player) {
        if (player == null) {
            return "Unknown";
        }
        String name = player.getGameProfile().name();
        return name == null ? player.getUUID().toString() : name;
    }

    /**
     * Players the given viewer may currently call: online, not the viewer, not busy,
     * and callable. The client never computes this itself.
     */
    private static List<PlayerListPacket.Contact> collectCallablePlayers(ServerPlayer viewer) {
        List<PlayerListPacket.Contact> result = new ArrayList<>();
        for (ServerPlayer other : CallManager.getInstance().getCallablePlayers(viewer)) {
            result.add(new PlayerListPacket.Contact(other.getUUID(), nameOf(other)));
        }
        return result;
    }
}