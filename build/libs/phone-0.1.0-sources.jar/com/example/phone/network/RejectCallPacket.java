package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * CLIENT -> SERVER: "I reject the incoming call".
 */
public record RejectCallPacket() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<RejectCallPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.REJECT_CALL);

    public static final StreamCodec<RegistryFriendlyByteBuf, RejectCallPacket> CODEC =
            StreamCodec.of((buf, value) -> {
            }, buf -> new RejectCallPacket());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}