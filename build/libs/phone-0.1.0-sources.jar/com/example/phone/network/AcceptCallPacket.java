package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * CLIENT -> SERVER: "I accept the call I was invited to".
 * The client never sends a state; the server decides whether the call becomes CONNECTED.
 */
public record AcceptCallPacket() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<AcceptCallPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.ACCEPT_CALL);

    public static final StreamCodec<RegistryFriendlyByteBuf, AcceptCallPacket> CODEC =
            StreamCodec.of((buf, value) -> {
            }, buf -> new AcceptCallPacket());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}