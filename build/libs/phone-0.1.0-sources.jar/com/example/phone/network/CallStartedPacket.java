package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.UUID;

/**
 * SERVER -> CLIENT: your call is now CONNECTED.
 *
 * @param peerId   the other party
 * @param peerName their name
 */
public record CallStartedPacket(UUID peerId, String peerName) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<CallStartedPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.CALL_STARTED);

    public static final StreamCodec<RegistryFriendlyByteBuf, CallStartedPacket> CODEC =
            StreamCodec.of((buf, value) -> {
                buf.writeUUID(value.peerId());
                buf.writeUtf(value.peerName());
            }, buf -> new CallStartedPacket(buf.readUUID(), buf.readUtf()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}