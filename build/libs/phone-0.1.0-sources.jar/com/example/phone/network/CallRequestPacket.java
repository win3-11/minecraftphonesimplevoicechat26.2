package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import java.util.UUID;

/**
 * CLIENT -> SERVER: "I want to call this player".
 * The UUID is only a request; the server resolves it and validates everything.
 */
public record CallRequestPacket(UUID targetId) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<CallRequestPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.CALL_REQUEST);

    public static final StreamCodec<RegistryFriendlyByteBuf, CallRequestPacket> CODEC =
            StreamCodec.of((buf, value) -> buf.writeUUID(value.targetId()),
                    buf -> new CallRequestPacket(buf.readUUID()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}