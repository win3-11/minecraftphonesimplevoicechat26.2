package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * CLIENT -> SERVER: "please send me the current list of callable players".
 */
public record PlayerListRequestPacket() implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<PlayerListRequestPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.PLAYER_LIST_REQUEST);

    public static final StreamCodec<RegistryFriendlyByteBuf, PlayerListRequestPacket> CODEC =
            StreamCodec.of((buf, value) -> {
            }, buf -> new PlayerListRequestPacket());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}