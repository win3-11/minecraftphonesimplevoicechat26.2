package com.example.phone.network;

import com.example.phone.PhoneIds;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * SERVER -> CLIENT: somebody is calling you.
 *
 * @param callerId    the caller
 * @param callerName  their name, so the GUI needs no extra lookup
 */
public record IncomingCallPacket(java.util.UUID callerId, String callerName) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<IncomingCallPacket> TYPE =
            new CustomPacketPayload.Type<>(PhoneIds.INCOMING_CALL);

    public static final StreamCodec<RegistryFriendlyByteBuf, IncomingCallPacket> CODEC =
            StreamCodec.of((buf, value) -> {
                buf.writeUUID(value.callerId());
                buf.writeUtf(value.callerName());
            }, buf -> new IncomingCallPacket(buf.readUUID(), buf.readUtf()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}