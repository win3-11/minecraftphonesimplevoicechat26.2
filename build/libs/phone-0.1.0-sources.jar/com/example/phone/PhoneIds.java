package com.example.phone;

import net.minecraft.resources.Identifier;

public final class PhoneIds {
    public static final String MOD_ID = "phone";

    public static final Identifier PLAYER_LIST = Identifier.fromNamespaceAndPath(MOD_ID, "player_list");
    public static final Identifier INCOMING_CALL = Identifier.fromNamespaceAndPath(MOD_ID, "incoming_call");
    public static final Identifier CALL_STARTED = Identifier.fromNamespaceAndPath(MOD_ID, "call_started");
    public static final Identifier CALL_ENDED = Identifier.fromNamespaceAndPath(MOD_ID, "call_ended");

    public static final Identifier PLAYER_LIST_REQUEST = Identifier.fromNamespaceAndPath(MOD_ID, "player_list_request");
    public static final Identifier CALL_REQUEST = Identifier.fromNamespaceAndPath(MOD_ID, "call_request");
    public static final Identifier ACCEPT_CALL = Identifier.fromNamespaceAndPath(MOD_ID, "accept_call");
    public static final Identifier REJECT_CALL = Identifier.fromNamespaceAndPath(MOD_ID, "reject_call");
    public static final Identifier HANG_UP = Identifier.fromNamespaceAndPath(MOD_ID, "hang_up");

    private PhoneIds() {
    }
}