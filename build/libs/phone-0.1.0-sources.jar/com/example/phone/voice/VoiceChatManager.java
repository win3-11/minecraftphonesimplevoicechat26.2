package com.example.phone.voice;

import com.example.phone.PhoneMod;
import de.maxhenkel.voicechat.api.Group;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.plugins.impl.VoicechatServerApiImpl;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * The only place that talks to Simple Voice Chat.
 *
 * Everything else in the mod works with plain UUIDs, so if the voice chat API changes
 * only this class has to be updated.
 *
 * Verified against Simple Voice Chat 2.6.24+26.2 (see README):
 *   VoicechatServerApiImpl.instance()                        -> VoicechatServerApi
 *   groupBuilder().setId(..).setName(..).setType(..).build() -> Group
 *   getConnectionOf(uuid).setGroup(group)
 *   removeGroup(groupId)
 *
 * Note: the public Group interface has no "list players" method, so membership is tracked
 * here in order to be able to delete a group once the last participant leaves.
 */
public final class VoiceChatManager {

    private static final String GROUP_PREFIX = "phone-call-";
    private static final String GROUP_PASSWORD = "phone-internal";

    /** player UUID -> the voice group it was put into. */
    private static final Map<UUID, UUID> playerToGroup = new HashMap<>();

    /** voice group id -> the players we put into it. */
    private static final Map<UUID, Set<UUID>> groupMembers = new HashMap<>();

    private VoiceChatManager() {
    }

    /**
     * Creates an OPEN voice group for the call: the two members hear one another over
     * any distance, while nearby players can also hear a member speaking locally.
     * The group remains hidden and password-protected to prevent unsolicited joins.
     *
     * @return the group id, or null if the voice connection could not be established
     */
    public static UUID connectPlayers(ServerPlayer a, ServerPlayer b) {
        VoicechatServerApi api = api();
        if (api == null || a == null || b == null) {
            return null;
        }

        try {
            UUID groupId = UUID.randomUUID();
            Group group = api.groupBuilder()
                    .setId(groupId)
                    .setName(GROUP_PREFIX + groupId)
                    .setPassword(GROUP_PASSWORD)
                    .setPersistent(false)
                    .setHidden(true)
                    .setType(Group.Type.OPEN)
                    .build();

            VoicechatConnection connA = api.getConnectionOf(a.getUUID());
            VoicechatConnection connB = api.getConnectionOf(b.getUUID());
            if (connA == null || connB == null) {
                PhoneMod.LOGGER.warn("[phone] no Simple Voice Chat connection for one of the players");
                return null;
            }

            connA.setGroup(group);
            connB.setGroup(group);

            synchronized (playerToGroup) {
                playerToGroup.put(a.getUUID(), groupId);
                playerToGroup.put(b.getUUID(), groupId);
                groupMembers.computeIfAbsent(groupId, k -> new HashSet<>())
                        .addAll(List.of(a.getUUID(), b.getUUID()));
            }

            PhoneMod.LOGGER.info("[phone] voice group {} created for {} participants", groupId, 2);
            return groupId;
        } catch (Throwable t) {
            PhoneMod.LOGGER.error("[phone] failed to connect voice players", t);
            return null;
        }
    }

    /**
     * Removes both players from their group and deletes the group. Safe to call twice.
     */
    public static void disconnectPlayers(UUID groupId, ServerPlayer a, ServerPlayer b) {
        VoicechatServerApi api = api();
        if (api == null) {
            return;
        }
        try {
            if (a != null) {
                leaveGroup(api, a.getUUID());
            }
            if (b != null) {
                leaveGroup(api, b.getUUID());
            }
            if (groupId != null) {
                synchronized (playerToGroup) {
                    groupMembers.remove(groupId);
                }
                api.removeGroup(groupId);
            }
        } catch (Throwable t) {
            PhoneMod.LOGGER.error("[phone] failed to disconnect voice players", t);
        }
    }

    /** A player left the server: make sure they are not left inside a voice group. */
    public static void handleDisconnect(ServerPlayer player) {
        VoicechatServerApi api = api();
        if (api == null) {
            return;
        }
        try {
            UUID groupId;
            Set<UUID> members;
            synchronized (playerToGroup) {
                groupId = playerToGroup.remove(player.getUUID());
                if (groupId == null) {
                    return;
                }
                Set<UUID> set = groupMembers.get(groupId);
                members = set == null ? null : new HashSet<>(set);
                if (members != null) {
                    members.remove(player.getUUID());
                    groupMembers.put(groupId, members);
                }
            }

            // If nobody is left in the group, remove it entirely.
            if (members == null || members.isEmpty()) {
                api.removeGroup(groupId);
                synchronized (playerToGroup) {
                    groupMembers.remove(groupId);
                }
            }
            PhoneMod.LOGGER.info("[phone] cleaned up voice group {} after disconnect", groupId);
        } catch (Throwable t) {
            PhoneMod.LOGGER.error("[phone] failed to clean up voice group", t);
        }
    }

    /** Called when the server stops, so no stale groups are left behind. */
    public static void reset() {
        synchronized (playerToGroup) {
            playerToGroup.clear();
            groupMembers.clear();
        }
    }

    private static void leaveGroup(VoicechatServerApi api, UUID playerId) {
        VoicechatConnection connection = api.getConnectionOf(playerId);
        if (connection != null && connection.isInGroup()) {
            connection.setGroup(null);
        }
        synchronized (playerToGroup) {
            playerToGroup.remove(playerId);
        }
    }

    private static VoicechatServerApi api() {
        try {
            return VoicechatServerApiImpl.instance();
        } catch (Throwable t) {
            return null;
        }
    }
}