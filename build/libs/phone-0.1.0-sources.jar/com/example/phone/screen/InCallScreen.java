package com.example.phone.screen;

import com.example.phone.network.HangUpPacket;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import static net.minecraft.network.chat.Component.translatable;

/**
 * Shown to both parties while the call is CONNECTED.
 */
public class InCallScreen extends Screen {

    private static InCallScreen instance;

    private final String peerName;
    private final java.util.UUID peerId;

    public InCallScreen(java.util.UUID peerId, String peerName) {
        super(Component.literal("In call"));
        this.peerId = peerId;
        this.peerName = peerName;
    }

    public static InCallScreen getOpenScreen() {
        return instance;
    }

    public static void open(java.util.UUID peerId, String peerName) {
        InCallScreen screen = new InCallScreen(peerId, peerName);
        instance = screen;
        Minecraft client = Minecraft.getInstance();
        if (client.isSameThread()) {
            client.setScreenAndShow(screen);
        } else {
            client.execute(() -> client.setScreenAndShow(screen));
        }
    }

    public static void closeIfOpen() {
        if (instance == null) {
            return;
        }
        instance = null;
        Minecraft client = Minecraft.getInstance();
        if (client.isSameThread()) {
            client.setScreenAndShow(null);
        } else {
            client.execute(() -> client.setScreenAndShow(null));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        int centerX = width / 2;
        addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                centerX - 120, height / 2 - 62, 240, 18,
                translatable("phone.gui.in_call_with", peerName), this.font));
        // The active-call screen is intentionally not used as a forced overlay.
        // The call is shown inside the Phone screen; closing this screen returns to gameplay.
        addRenderableWidget(Button.builder(translatable("phone.gui.close"), b -> closeIfOpen())
                .bounds(width / 2 - 100, height / 2 + 10, 200, 20)
                .build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }
}