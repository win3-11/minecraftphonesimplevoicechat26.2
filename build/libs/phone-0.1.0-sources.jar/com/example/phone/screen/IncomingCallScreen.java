package com.example.phone.screen;

import com.example.phone.network.AcceptCallPacket;
import com.example.phone.network.RejectCallPacket;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.UUID;

import static net.minecraft.network.chat.Component.translatable;

/**
 * Shown to the callee while the call is RINGING. Accept / Reject only ask the server;
 * the server decides whether the call really starts.
 */
public class IncomingCallScreen extends Screen {

    private static IncomingCallScreen instance;

    private final String callerName;
    private final UUID callerId;

    public IncomingCallScreen(UUID callerId, String callerName) {
        super(Component.literal("Incoming call"));
        this.callerId = callerId;
        this.callerName = callerName;
    }

    /** Closes the window without triggering a reject (the call is already over). */
    public static void clear() {
        IncomingCallScreen screen = instance;
        instance = null;
        if (screen == null) {
            return;
        }
        Minecraft client = Minecraft.getInstance();
        if (client.isSameThread()) {
            client.setScreenAndShow(null);
        } else {
            client.execute(() -> client.setScreenAndShow(null));
        }
    }

    public static IncomingCallScreen getOpenScreen() {
        return instance;
    }

    /** Closes the window without triggering a reject. */
    private void closeSelf() {
        if (instance == this) {
            instance = null;
        }
        Minecraft client = Minecraft.getInstance();
        if (client.isSameThread()) {
            client.setScreenAndShow(null);
        } else {
            client.execute(() -> client.setScreenAndShow(null));
        }
    }

    public static void open(UUID callerId, String callerName) {
        // Do not interrupt an active call screen with a second incoming call.
        if (instance != null) {
            return;
        }
        Minecraft client = Minecraft.getInstance();
        if (!client.isSameThread()) {
            client.execute(() -> open(callerId, callerName));
            return;
        }
        IncomingCallScreen screen = new IncomingCallScreen(callerId, callerName);
        instance = screen;
        client.setScreenAndShow(screen);
    }

    @Override
    public void onClose() {
        // Closing the window without answering counts as rejecting.
        if (instance == this) {
            instance = null;
            ClientPlayNetworking.send(new com.example.phone.network.RejectCallPacket());
        }
        super.onClose();
    }

    @Override
    protected void init() {
        int centerX = width / 2;
        addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                centerX - 120, height / 2 - 62, 240, 18,
                translatable("phone.gui.incoming_title"), this.font));
        addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                centerX - 120, height / 2 - 38, 240, 18,
                translatable("phone.gui.incoming_from", callerName), this.font));

        int y = height / 2 - 10;

        addRenderableWidget(Button.builder(translatable("phone.gui.accept"), b -> {
            ClientPlayNetworking.send(new AcceptCallPacket());
            // Keep this screen until the server confirms CONNECTED or ENDED.
            // The server is authoritative and may have cancelled the call already.
        })
                .bounds(width / 2 - 105, y, 100, 20)
                .build());

        addRenderableWidget(Button.builder(translatable("phone.gui.reject"), b -> {
            ClientPlayNetworking.send(new RejectCallPacket());
            closeSelf();
        })
                .bounds(width / 2 + 5, y, 100, 20)
                .build());
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }
}