package com.example.phone.screen;

import com.example.phone.network.PlayerListPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

import static net.minecraft.network.chat.Component.translatable;

/**
 * Minimal phone GUI. It only displays what the server sent in PlayerListPacket, so the
 * client performs no availability checks of its own.
 *
 * <p>Each row is a real widget (name + CALL button) instead of hand-drawn text, so the
 * server list becomes visible the moment it arrives and is re-created only when it
 * actually changed.
 */
public class PhoneScreen extends Screen {
    private static final int ROW_HEIGHT = 23;
    private static final int MAX_VISIBLE = 8;
    private static final int REFRESH_INTERVAL_TICKS = 60;
    private static final int PANEL_WIDTH = 248;
    private static final int PANEL_TOP = 18;

    private static PhoneScreen instance;

    private final List<PlayerListPacket.Contact> contacts = new ArrayList<>();
    private net.minecraft.client.gui.components.StringWidget callStatus;
    private int ticksSinceLastRequest = 0;

    public PhoneScreen() {
        super(Component.literal("Phone"));
    }

    public static PhoneScreen getOpenScreen() {
        return instance;
    }

    public static void refreshIfOpen() {
        if (instance == null) {
            return;
        }
        instance.rebuildWidgets();
    }

    /**
     * Opens the phone GUI on the client (render) thread.
     *
     * <p>The item is used from the server thread, and in 26.2 {@code UseItemCallback}
     * runs on the <em>server</em> thread even in singleplayer, so opening the screen
     * there throws "Rendersystem called from wrong thread".
     */
    public static void open() {
        Minecraft client = Minecraft.getInstance();
        if (!client.isSameThread()) {
            client.execute(PhoneScreen::open);
            return;
        }
        PhoneScreen screen = new PhoneScreen();
        instance = screen;
        client.setScreenAndShow(screen);
        // Request once when the screen opens. init() can also be called by
        // rebuildWidgets(), so requesting from init() would create a response loop.
        PhoneModClient.requestPlayerList();
    }

    @Override
    public void onClose() {
        instance = null;
        super.onClose();
    }

    /**
     * Replaces the list and re-creates the rows when the content actually changed.
     *
     * <p>No request is sent from here on purpose: {@code rebuildWidgets()} calls
     * {@code init()}, and {@code init()} asks the server for the list again, which would
     * start an endless request/response loop.
     */
    public void setContacts(List<PlayerListPacket.Contact> newContacts) {
        if (sameContent(newContacts)) {
            return;
        }
        this.contacts.clear();
        this.contacts.addAll(newContacts);
        if (this.minecraft != null && !PhoneModClient.isConnected()) {
            this.rebuildWidgets();
        }
    }

    private boolean sameContent(List<PlayerListPacket.Contact> other) {
        if (other.size() != contacts.size()) {
            return false;
        }
        for (int i = 0; i < other.size(); i++) {
            PlayerListPacket.Contact incoming = other.get(i);
            PlayerListPacket.Contact current = contacts.get(i);
            if (!incoming.uuid().equals(current.uuid())
                    || !incoming.name().equals(current.name())) {
                return false;
            }
        }
        return true;
    }

    @Override
    protected void init() {
        ticksSinceLastRequest = 0;
        buildRows();
    }

    private void buildRows() {
        int centerX = width / 2;
        boolean connected = PhoneModClient.isConnected();
        int panelX = centerX - PANEL_WIDTH / 2;
        int headingY = PANEL_TOP + 16;
        addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                centerX - 110, headingY, 220, 18,
                translatable("phone.gui.title"), this.font));

        if (connected) {
            addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                    centerX - 110, PANEL_TOP + 48, 220, 18,
                    translatable("phone.gui.connected"), this.font));
            callStatus = new net.minecraft.client.gui.components.StringWidget(
                    centerX - 112, PANEL_TOP + 70, 224, 18, Component.empty(), this.font);
            addRenderableOnly(callStatus);
            addRenderableWidget(Button.builder(translatable("phone.gui.hang_up"),
                            b -> PhoneModClient.hangUp())
                    .bounds(centerX - 100, PANEL_TOP + 106, 200, 20).build());
            addRenderableWidget(Button.builder(translatable("phone.gui.close"), b -> onClose())
                    .bounds(centerX - 100, PANEL_TOP + 134, 200, 20).build());
            return;
        }

        callStatus = null;
        addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                centerX - 110, PANEL_TOP + 42, 220, 18,
                translatable("phone.gui.call_prompt"), this.font));
        if (PhoneModClient.hasNotice()) {
            addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                    centerX - 120, PANEL_TOP + 58, 240, 18,
                    translatable(PhoneModClient.noticeKey(), PhoneModClient.noticeArg()),
                    this.font));
        }

        int listTop = PANEL_TOP + 70;
        if (contacts.isEmpty()) {
            addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                    centerX - 110, listTop + 10, 220, 18,
                    translatable("phone.gui.no_players"), this.font));
        }
        int shown = Math.min(contacts.size(), MAX_VISIBLE);
        for (int i = 0; i < shown; i++) {
            final PlayerListPacket.Contact contact = contacts.get(i);
            int y = listTop + i * ROW_HEIGHT;
            addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                    panelX + 20, y + 1, 136, 18,
                    Component.literal(contact.name()), this.font));
            addRenderableWidget(Button.builder(translatable("phone.gui.call"),
                            b -> PhoneModClient.requestCall(contact.uuid()))
                    .bounds(centerX + 40, y, 65, 20).build());
        }
        if (contacts.size() > MAX_VISIBLE) {
            addRenderableOnly(new net.minecraft.client.gui.components.StringWidget(
                    centerX - 105, listTop + shown * ROW_HEIGHT, 210, 18,
                    translatable("phone.gui.more", contacts.size() - MAX_VISIBLE), this.font));
        }
        int closeY = listTop + Math.max(2, shown) * ROW_HEIGHT + 16;
        addRenderableWidget(Button.builder(translatable("phone.gui.close"), b -> onClose())
                .bounds(centerX - 100, closeY, 200, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        int panelX = width / 2 - PANEL_WIDTH / 2;
        int panelBottom = PhoneModClient.isConnected() ? PANEL_TOP + 171
                : PANEL_TOP + 70 + Math.max(2, Math.min(contacts.size(), MAX_VISIBLE)) * ROW_HEIGHT + 50;
        graphics.fill(panelX - 3, PANEL_TOP - 3, panelX + PANEL_WIDTH + 3, panelBottom + 3, 0xFF0A0E18);
        graphics.fill(panelX, PANEL_TOP, panelX + PANEL_WIDTH, panelBottom, 0xEF1B2739);
        graphics.fill(panelX, PANEL_TOP, panelX + PANEL_WIDTH, PANEL_TOP + 4, 0xFF44C3C1);
        graphics.fill(panelX + 14, PANEL_TOP + 40, panelX + PANEL_WIDTH - 14, PANEL_TOP + 41, 0xFF40546A);
        if (callStatus != null) {
            long elapsed = PhoneModClient.callElapsedSeconds();
            callStatus.setMessage(translatable("phone.gui.in_call",
                    PhoneModClient.connectedPeerName(), elapsed / 60, elapsed % 60));
        }

        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        // The phone must NOT pause the game: you use it while playing.
        return false;
    }

    @Override
    public void tick() {
        ticksSinceLastRequest++;
        if (ticksSinceLastRequest >= REFRESH_INTERVAL_TICKS) {
            ticksSinceLastRequest = 0;
            if (!PhoneModClient.isConnected()) {
                PhoneModClient.requestPlayerList();
            }
        }
    }
}