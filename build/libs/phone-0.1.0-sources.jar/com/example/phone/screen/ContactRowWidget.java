package com.example.phone.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * One row of the phone list: the player name plus a CALL button.
 *
 * <p>Using a real widget for the name means the list is drawn by the normal widget
 * pipeline, so it shows up as soon as the server data arrives instead of depending on
 * manual text drawing in extractRenderState().
 */
public class ContactRowWidget extends AbstractWidget {

    private final Screen parent;
    private final Button callButton;

    public ContactRowWidget(Screen parent, String name, Button.OnPress onCall,
                            int x, int y, int width, int height) {
        super(x, y, width, height, Component.literal(name));
        this.parent = parent;

        this.callButton = Button.builder(Component.literal("CALL"), onCall)
                .bounds(x + width - 64, y + 1, 62, height - 2)
                .build();
    }

    /** The nested button must be registered on the screen separately. */
    public Button callButton() {
        return callButton;
    }

    @Override
    protected void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        graphics.fill(
                getX(), getY(),
                getX() + getWidth(), getY() + getHeight(),
                isHoveredOrFocused() ? 0x80303040 : 0x60202028);

        int textX = getX() + 6;
        graphics.text(parent.getFont(), getMessage(), textX,
                getY() + (getHeight() - parent.getFont().lineHeight) / 2 + 1, 0xFFFFFF);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        output.add(NarratedElementType.TITLE, getMessage());
    }
}