package com.example.phone.screen;

import com.example.phone.item.PhoneItem;
import com.example.phone.network.AcceptCallPacket;
import com.example.phone.network.CallEndedPacket;
import com.example.phone.network.CallRequestPacket;
import com.example.phone.network.CallStartedPacket;
import com.example.phone.network.HangUpPacket;
import com.example.phone.network.IncomingCallPacket;
import com.example.phone.network.PlayerListPacket;
import com.example.phone.network.PlayerListRequestPacket;
import com.example.phone.network.RejectCallPacket;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.world.InteractionResult;

import java.util.UUID;

public class PhoneModClient implements ClientModInitializer {
    private static UUID connectedPeerId;
    private static String connectedPeerName = "Unknown";
    private static long connectedAtMillis;

    public static boolean isConnected() {
        return connectedPeerId != null;
    }

    public static String connectedPeerName() {
        return connectedPeerName;
    }

    public static long callElapsedSeconds() {
        return connectedAtMillis == 0 ? 0 : Math.max(0, (System.currentTimeMillis() - connectedAtMillis) / 1000);
    }

    private static String noticeKey;
    private static String noticeArg;
    private static long noticeUntilMillis;

    /**
     * Shows a short one-line explanation in the phone GUI, e.g. when a call was cancelled
     * because the other player had no phone. Key must be a {@code phone.gui.*} entry.
     */
    public static void showNotice(String key, String arg) {
        noticeKey = key;
        noticeArg = arg;
        noticeUntilMillis = System.currentTimeMillis() + 4000;
    }

    public static boolean hasNotice() {
        return noticeKey != null && System.currentTimeMillis() < noticeUntilMillis;
    }

    public static String noticeKey() {
        return noticeKey;
    }

    public static String noticeArg() {
        return noticeArg;
    }

    public static void clearNotice() {
        noticeKey = null;
        noticeArg = null;
    }

    @Override
    public void onInitializeClient() {
        // Payload types are registered in the common initializer (PhoneMod).

        // The phone item returns PASS/ SUCCESS without opening anything, so the GUI is
        // opened here, client side only.
        UseItemCallback.EVENT.register((player, level, hand) -> {
            if (player.getItemInHand(hand).getItem() instanceof PhoneItem) {
                PhoneScreen.open();
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });

        ClientPlayNetworking.registerGlobalReceiver(PlayerListPacket.TYPE, (payload, context) ->
                context.client().execute(() -> {
                    PhoneScreen screen = PhoneScreen.getOpenScreen();
                    if (screen != null) {
                        screen.setContacts(payload.contacts());
                    }
                }));

        ClientPlayNetworking.registerGlobalReceiver(IncomingCallPacket.TYPE, (payload, context) ->
                context.client().execute(() ->
                        IncomingCallScreen.open(payload.callerId(), payload.callerName())));

        ClientPlayNetworking.registerGlobalReceiver(CallStartedPacket.TYPE, (payload, context) ->
                context.client().execute(() -> {
                    connectedPeerId = payload.peerId();
                    connectedPeerName = payload.peerName();
                    connectedAtMillis = System.currentTimeMillis();
                    IncomingCallScreen.clear();
                    // Do not force an in-call overlay. The player opens the phone
                    // manually to see the peer, duration, and HANG UP button.
                    InCallScreen.closeIfOpen();
                    PhoneScreen.refreshIfOpen();
                }));

        ClientPlayNetworking.registerGlobalReceiver(CallEndedPacket.TYPE, (payload, context) ->
                context.client().execute(() -> {
                    // The server always ends the call for both sides, so just clear any
                    // call screen. Repeat notifications are harmless.
                    IncomingCallScreen.clear();
                    InCallScreen.closeIfOpen();
                    connectedPeerId = null;
                    connectedPeerName = "Unknown";
                    connectedAtMillis = 0;
                    if ("no_phone".equals(payload.reason())) {
                        showNotice("phone.gui.notice_no_phone", "");
                    } else if ("rejected".equals(payload.reason())) {
                        showNotice("phone.gui.notice_rejected", "");
                    } else {
                        clearNotice();
                    }
                    PhoneScreen.refreshIfOpen();
                }));
    }

    /** Called by the GUI to ask the server to place a call. */
    public static void requestCall(java.util.UUID targetId) {
        ClientPlayNetworking.send(new CallRequestPacket(targetId));
    }

    public static void acceptCall() {
        ClientPlayNetworking.send(new AcceptCallPacket());
    }

    public static void rejectCall() {
        ClientPlayNetworking.send(new RejectCallPacket());
    }

    public static void hangUp() {
        ClientPlayNetworking.send(new HangUpPacket());
    }

    public static void clearConnectedCall() {
        connectedPeerId = null;
        connectedPeerName = "Unknown";
        connectedAtMillis = 0;
    }

    /** Called by the GUI when it opens or wants fresh data. */
    public static void requestPlayerList() {
        ClientPlayNetworking.send(new PlayerListRequestPacket());
    }
}