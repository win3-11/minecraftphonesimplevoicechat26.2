package com.example.phone.phone;

import com.example.phone.PhoneMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/**
 * All phone sound effects, isolated here so the event names live in one place.
 *
 * <p>These are vanilla Minecraft sounds on purpose: they are already in the client jar, so
 * nothing has to be registered, no {@code sounds.json} is needed, and they work for every
 * player without extra downloads. Swap them for custom {@code SoundEvent}s later by
 * registering them and changing only this file.
 */
public final class PhoneSounds {

    /** Played to the player who is being called — a real bell, not a note block. */
    public static final SoundEvent RINGING = SoundEvents.BELL_BLOCK;

    /** Played to both sides when the call is accepted. */
    public static final SoundEvent ACCEPTED = SoundEvents.EXPERIENCE_ORB_PICKUP;

    /** Played to both sides when the call ends for any reason. */
    public static final SoundEvent ENDED = SoundEvents.BREWING_STAND_BREW;

    private PhoneSounds() {
    }

    /** Rings for the player who is being called. */
    public static void playRinging(ServerPlayer player) {
        play(player, RINGING, 0.9F, 1.6F);
    }

    public static void playAccepted(ServerPlayer player) {
        play(player, ACCEPTED, 0.8F, 1.6F);
    }

    public static void playEnded(ServerPlayer player) {
        play(player, ENDED, 0.9F, 0.8F);
    }

    /**
     * Plays a sound only to this one player, wherever they are. {@code
     * Player.playSound(SoundEvent, float, float)} is a per-player call, so this is
     * distance-independent — which is what a phone needs: the ringing must be audible
     * wherever the player happens to be standing.
     */
    public static void play(ServerPlayer player, SoundEvent sound, float volume, float pitch) {
        if (player == null) {
            return;
        }
        try {
            player.playSound(sound, volume, pitch);
        } catch (Throwable t) {
            // A missing sound must never break a call.
            PhoneMod.LOGGER.warn("[phone] failed to play sound {}", sound, t);
        }
    }
}
